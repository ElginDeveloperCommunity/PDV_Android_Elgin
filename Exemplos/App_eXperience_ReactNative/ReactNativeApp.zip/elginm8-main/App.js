import React from 'react';
import Routes from './src/Routes';
const App =()=> {
  return (
    <Routes/>
  );
};



export default App;
